package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Barang;

public class BarangDAO {
    public boolean insert(Barang b) {
        String sql = "INSERT INTO barang VALUES(?,?,?,?)";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, b.getKodeBarang());
            ps.setString(2, b.getNamaBarang());
            ps.setString(3, b.getKategori());
            ps.setInt(4, b.getStok());
            ps.executeUpdate();
            return true;
        } catch (Exception e) { return false; }
    }
    public boolean update(Barang b) {
        String sql = "UPDATE barang SET nama_barang=?, kategori=?, stok=? WHERE kode_barang=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, b.getNamaBarang());
            ps.setString(2, b.getKategori());
            ps.setInt(3, b.getStok());
            ps.setString(4, b.getKodeBarang());
            ps.executeUpdate();
            return true;
        } catch (Exception e) { return false; }
    }
    public boolean delete(String kode) {
        String sql = "DELETE FROM barang WHERE kode_barang=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kode);
            ps.executeUpdate();
            return true;
        } catch (Exception e) { return false; }
    }
    public List<Barang> getAll() {
        List<Barang> list = new ArrayList<>();
        try (Connection conn = Koneksi.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM barang")) {
            while (rs.next()) {
                list.add(new Barang(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4)));
            }
        } catch (Exception e) {}
        return list;
    }
}